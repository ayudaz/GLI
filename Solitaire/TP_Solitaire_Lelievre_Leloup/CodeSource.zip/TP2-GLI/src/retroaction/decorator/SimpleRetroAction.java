package retroaction.decorator;

public class SimpleRetroAction implements RetroAction {

	@Override
	public void faireRetroAction() {
		
	}

}
