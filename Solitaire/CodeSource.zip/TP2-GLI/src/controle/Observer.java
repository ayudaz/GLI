package controle;

public interface Observer {
	public void update();
}
