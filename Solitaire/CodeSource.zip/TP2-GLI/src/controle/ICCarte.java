package controle;

public interface ICCarte {

}
