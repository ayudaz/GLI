package presentation;

public interface IPTas {

}
