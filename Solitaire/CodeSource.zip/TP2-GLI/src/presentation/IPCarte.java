package presentation;

public interface IPCarte {

}
