package presentation;

import controle.ICTas;

public class PTasDeCartesAlternees extends PTasDeCartes {

	private static final long serialVersionUID = -7863237146322163621L;

	public PTasDeCartesAlternees(ICTas cTasDeCartesAlternees) {
		super(cTasDeCartesAlternees);
	}

}
