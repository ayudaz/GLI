package retroaction.decorator;

public interface RetroAction {
	
	public void faireRetroAction();

}
